<?php

/*
 * Use this to get the option names of the plugin
 */
function get_plugin_text_bold_options($name){
	return carbon_get_theme_option($name);
}