<?php

if(!defined('ABSPATH')) die("You don't have permission to access this page.");

/*
 * Stylesheet for admin
 */
function load_text_bold_stylesheets(){
    wp_enqueue_style('text-bold-stylesheet', TEXT_BOLD_PLUGIN_BASE_URL . '/assets/css/admin.css', array(), 1, 'all');
}

add_action('admin_head', 'load_text_bold_stylesheets', false);

/*
 * Transform text to bold handler
 */
function transform_text_to_bold($content) {
    $option_text = get_plugin_text_bold_options('field_text_bold');

    return $option_text ? str_replace($option_text, '<strong>' . $option_text . '</strong>', $content) : $content;
}

add_filter('the_content', 'transform_text_to_bold');