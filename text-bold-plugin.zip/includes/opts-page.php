<?php if(!defined('ABSPATH')) die("You don't have permission to access this page.");

use Carbon_Fields\Container;
use Carbon_Fields\Field;

/*
 * Initialize Fields
 */
function load_text_bold_fields(){
    \Carbon_Fields\Carbon_Fields::boot();
}

add_action('after_setup_theme', 'load_text_bold_fields');

/*
 * Create theme options
 */
function create_bold_text_options_page(){
    Container::make('theme_options', 'Text Bold')
        ->set_page_menu_position(80)
        ->set_icon('dashicons-admin-generic')
        ->add_fields( array(
            Field::make('text', 'field_text_bold', __('Input Text here'))
                ->set_help_text('The value in this field will match the text in the post and page then transform it to bold text.')
        ));
}

add_action('carbon_fields_register_fields', 'create_bold_text_options_page');