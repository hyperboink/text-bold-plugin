<?php
/*
 * Plugin Name: Text Bold Plugin
 * Description: An exam that will change the matching text to bold.
 * Author: Alfie
 * Author URI: https://github.com/hyperboink/text-bold-plugin
 * Version: 1.0.0
 * Text-Domain: text-bold-plugin
 *
 */

if(!defined('ABSPATH')){
	die("You don't have permission to access this page.");
}

if(!class_exists('TextBoldPlugin')){

    class TextBoldPlugin{

        public function __construct(){

            /*
             * Contants that will be used across the plugin
             */
            define('TEXT_BOLD_PLUGIN_BASE_PATH', plugin_dir_path(__FILE__));
            define('TEXT_BOLD_PLUGIN_BASE_URL', plugin_dir_url(__FILE__));

            /*
             * Initialize autoload
             */
            require_once('vendor/autoload.php');
        }

        /*
         * Initialize the files in the include folder
         */
        public function initialize(){
            include_once TEXT_BOLD_PLUGIN_BASE_PATH . 'includes/utils.php';
            include_once TEXT_BOLD_PLUGIN_BASE_PATH . 'includes/opts-page.php';
            include_once TEXT_BOLD_PLUGIN_BASE_PATH . 'includes/controller.php';
        }

    }

}

/*
 * Instance and initialization of the plugin
 */
$text_bold_plugin = new TextBoldPlugin;

$text_bold_plugin->initialize();